<template>
  <div>
  	学迹卡实验班申请补课
  </div>
</template>

<script>
export default {
  data () {
  	return {
			
  	}
  },
  mounted (){
    let self = this;
  },
  methods: {
    
  }
}
</script>

<style scoped>
</style>
