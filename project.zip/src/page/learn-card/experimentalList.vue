<template>
  <div>
  	学迹卡实验班列表
  </div>
</template>

<script>
export default {
  data () {
  	return {
			
  	}
  },
  mounted (){
    let self = this;
  },
  methods: {
    
  }
}
</script>

<style scoped>
</style>
