<template>
  <div>
    学迹卡
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>
</style>
