<template>
  <div>
  	
  </div>
</template>

<script>
export default {
  data () {
  	return {
			
  	}
  },
  mounted (){
    let self = this;
  },
  methods: {
    
  }
}
</script>

<style scoped>
</style>
