<template>
  <div>
  	课程详情页面
  </div>
</template>

<script>
export default {
  data () {
  	return {
			
  	}
  },
  mounted (){
    let self = this;
  },
  methods: {
    
  }
}
</script>

<style scoped>
</style>
