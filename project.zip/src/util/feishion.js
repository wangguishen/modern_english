var text;
// function text(value) {
// 	return value + '年'
// }
text = (value) => {
	return value + '年'
}

export {
	text
}